﻿using HtmlAgilityPack;
using System.Collections.Generic;
using System.IO;

namespace courseCrawler
{
    public class Program
    {
        public static void Main(string[] args)
        {
            string url = "https://www.washington.edu/students/crscat/";
            List<string> majors = new List<string>();

            HtmlWeb web = new HtmlWeb();
            HtmlDocument doc = web.Load(url);
            var root = doc.DocumentNode.SelectNodes("//li/a");

            foreach (var node in root)
            {
                string major = node.Attributes["href"].Value;
                if (!majors.Contains(major) && !major.Contains("/") && major.Contains(".html"))
                {
                    majors.Add(major);
                }
            }

            foreach (string major in majors)
            {
                HtmlDocument majorDoc = web.Load(url + major);
                var majorRoot = majorDoc.DocumentNode.SelectNodes("//a[@name]");
                if (majorRoot != null)
                {
                    foreach (var node in majorRoot)
                    {
                        var bNode = node.FirstChild.FirstChild;
                        var brNode = bNode.NextSibling.NextSibling;
                        string courseTitle = bNode.InnerText;
                        string courseDesc = brNode.InnerText;

                        string[] courseInfo = courseTitle.Split(' ');

                        string courseAbbr = courseInfo[0];
                        string courseCode = courseInfo[1];
                        string courseName = "";

                        for (int i = 2; i < courseInfo.Length; i++)
                        {
                            if (!courseInfo[i].StartsWith("("))
                            {
                                courseName += courseInfo[i] + " ";
                            }
                            else
                            {
                                courseName = courseName.Trim();
                                break;
                            }
                        }
                        string credits = courseTitle.Split('(', ')')[1];
                        string type = courseTitle.Substring(courseTitle.IndexOf(')') + 1).Trim();
                        string prerequisite = "";

                        if (courseDesc.Contains("Prerequisite:"))
                        {
                            prerequisite = courseDesc.Substring(courseDesc.IndexOf("Prerequisite:") + 14);
                            prerequisite = prerequisite.Substring(0, prerequisite.Length - 1);
                            courseDesc = courseDesc.Substring(0, courseDesc.IndexOf("Prerequisite:"));
                        }

                        using (StreamWriter writer = new StreamWriter(@"\\Mac\Home\Desktop\info5.txt", true))
                        {
                            writer.WriteLine("CourseAbbr: " + courseAbbr);
                            writer.WriteLine("CourseCode: " + courseCode);
                            writer.WriteLine("CourseName: " + courseName);
                            writer.WriteLine("CourseDesc: " + courseDesc);
                            writer.WriteLine("Credits: " + credits);
                            writer.WriteLine("Type: " + type);
                            writer.WriteLine("Prerequisite: " + prerequisite);
                            writer.WriteLine("");

                        }
                    }
                }
            }
        }
    }
}
